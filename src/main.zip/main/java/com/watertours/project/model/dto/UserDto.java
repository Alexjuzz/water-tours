package com.watertours.project.model.dto;

import lombok.Data;

@Data
public class UserDto {
    private final String buyerName;
    private final String email;
    private final String phone;
}
