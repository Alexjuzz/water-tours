package com.watertours;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestHtmxApplicationTests {

	@Test
	void contextLoads() {
	}

}
