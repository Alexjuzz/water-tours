package com.watertours.project.enums;


import lombok.Getter;

@Getter
public enum TicketType {
    CHILD,SENIOR,DISCOUNT
}
